<#if package?? && package != "">
package ${package};

</#if>
/**
 * ${name}, made for ${project}, is copyright Blue Husky Programming, ©2013 <HR/>
 * 
 * @author ${user} of Blue Husky Programming
 * @version 1.0.0
 * @since ${date?date?string("yyyy")}-${date?date?string("MM")}-${date?date?string("dd")}
 */
public class ${name} {

}
